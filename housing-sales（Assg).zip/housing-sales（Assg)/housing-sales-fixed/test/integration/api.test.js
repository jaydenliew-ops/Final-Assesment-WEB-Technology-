const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
require('dotenv').config();
// NEVER allow these destructive fixtures on the normal app database.
if (!process.env.DB_NAME || !process.env.DB_NAME.endsWith('_test') || process.env.ALLOW_TEST_DB_RESET !== 'true') {
  throw new Error('Use a dedicated DB_NAME ending in _test and set ALLOW_TEST_DB_RESET=true. This test resets its tables.');
}
const mysql = require('mysql2/promise');
const request = require('supertest');
const app = require('../../app');
const db = require('../../database');
const service = require('../../services/reservations');
const demo = require('../../config').demoPayments;
let alice, bob, admin;
const buyer = { full_name: 'Alice Example', ic_number: 'P123456', phone: '0123456789', remarks: 'Test' };
async function seedUnit(name) {
  const [r] = await db.execute('INSERT INTO housing_units (project_name, unit_number, price_myr) VALUES (?, ?, 300000)', ['Test Project', name]);
  return r.insertId;
}
const auth = token => ({ Authorization: `Bearer ${token}` });
before(async () => {
  const connection = await mysql.createConnection({ host: process.env.DB_HOST || '127.0.0.1', port: Number(process.env.DB_PORT || 3306), user: process.env.DB_USER, password: process.env.DB_PASSWORD || '', database: process.env.DB_NAME, multipleStatements: true });
  try {
    await connection.query('DROP TABLE IF EXISTS unit_reservations; DROP TABLE IF EXISTS housing_units; DROP TABLE IF EXISTS buyers;');
    const schema = await fs.readFile(path.join(__dirname, '../../database.sql'), 'utf8');
    await connection.query(schema.replace(/^CREATE DATABASE[^;]+;/m, '').replace(/^USE housing_sales_db;/m, ''));
    const migration = await fs.readFile(path.join(__dirname, '../../migrations/001_security.sql'), 'utf8');
    await connection.query(migration);
    await connection.query(migration); // Repeatability.
  } finally { await connection.end(); }
  for (const name of ['alice', 'bob', 'admin']) {
    const response = await request(app).post('/api/auth/register').send({ name, email: `${name}@example.com`, password: 'Password123!' });
    assert.equal(response.status, 201);
  }
  await db.execute("UPDATE buyers SET role = 'admin' WHERE email = 'admin@example.com'");
  alice = (await request(app).post('/api/auth/login').send({ email: 'ALICE@example.com', password: 'Password123!' })).body.token;
  bob = (await request(app).post('/api/auth/login').send({ email: 'bob@example.com', password: 'Password123!' })).body.token;
  admin = (await request(app).post('/api/auth/login').send({ email: 'admin@example.com', password: 'Password123!' })).body.token;
  assert.ok(alice && bob && admin);
});
after(async () => { await db.end(); });
test('Private files are not exposed; public pages and root work', async () => {
  for (const url of ['/.env', '/database.sql', '/server.js', '/package.json', '/authMiddleware.js', '/%2e%2e/server.js']) {
    assert.equal((await request(app).get(url)).status, 404, url);
  }
  assert.equal((await request(app).get('/')).status, 302);
  assert.equal((await request(app).get('/login.html')).status, 200);
});
test('Login validates credentials; unsafe recovery is disabled', async () => {
  assert.equal((await request(app).post('/api/auth/login').send({ email: 'alice@example.com', password: 'wrong' })).status, 401);
  assert.equal((await request(app).post('/api/auth/register').send({ name: 'alice', email: 'alice@example.com', password: 'Password123!' })).status, 409);
  assert.equal((await request(app).post('/api/auth/register').send({ name: 'bad', email: 'bad@example.com', password: 'short' })).status, 400);
  assert.equal((await request(app).post('/api/auth/reset-password').send({ email: 'alice@example.com', newPassword: 'Attack123!' })).status, 503);
  assert.equal((await request(app).get('/api/auth/me').set(auth(alice))).body.user.name, 'alice');
});
test('Protected endpoints reject missing, fake and expired tokens', async () => {
  const jwt = require('jsonwebtoken');
  const expired = jwt.sign({ id: 1 }, process.env.JWT_SECRET, { expiresIn: -1, issuer: 'housing-sales', audience: 'housing-web' });
  for (const token of [null, 'test-bypass-token', expired]) {
    const headers = token ? auth(token) : {};
    assert.equal((await request(app).get('/api/my-reservations').set(headers)).status, 401);
    for (const action of ['reserve', 'pay-reservation', 'cancel-reservation', 'update-buyer-details']) assert.equal((await request(app).post(`/api/properties/${action}`).set(headers).send({})).status, 401);
  }
});
test('Only admins can add properties; coordinates and prices are validated', async () => {
  const property = { project_name: 'New', unit_number: 'N-1', price_myr: 1000, latitude: 0, longitude: 0 };
  assert.equal((await request(app).post('/api/properties').set(auth(alice)).send(property)).status, 403);
  assert.equal((await request(app).post('/api/properties').set(auth(admin)).send({ ...property, price_myr: -10 })).status, 400);
  assert.equal((await request(app).post('/api/properties').set(auth(admin)).send({ ...property, latitude: 91 })).status, 400);
  assert.equal((await request(app).post('/api/properties').set(auth(admin)).send(property)).status, 201);
});
test('Currency and filter validation; conversion explicitly indicative', async () => {
  assert.equal((await request(app).get('/api/properties?currency=EUR')).status, 400);
  assert.equal((await request(app).get('/api/properties?currency[]=USD')).status, 400);
  assert.equal((await request(app).get('/api/properties?bedrooms=1%20OR%201=1')).status, 400);
  const response = await request(app).get('/api/properties?currency=USD');
  assert.equal(response.status, 200);
  assert.equal(response.body.rate_type, 'indicative');
  assert.equal(response.body.data[0].display_currency, 'USD');
});
test('Bookings store ownership; other buyers cannot read or mutate records', async () => {
  const unit = await seedUnit('OWNERSHIP');
  const response = await request(app).post('/api/properties/reserve').set(auth(alice)).send({ ...buyer, unit_id: unit });
  assert.equal(response.status, 201);
  const id = response.body.data.reservation_id;
  const own = await request(app).get('/api/my-reservations').set(auth(alice));
  assert.ok(own.body.data.some(r => r.reservation_id === id && r.buyer_id && r.created_at && r.expires_at));
  for (const token of [bob, admin]) assert.ok(!(await request(app).get('/api/auth/my-reservations').set(auth(token))).body.data.some(r => r.reservation_id === id));
  assert.equal((await request(app).post('/api/properties/update-buyer-details').set(auth(bob)).send({ ...buyer, reservation_id: id })).status, 404);
  assert.equal((await request(app).post('/api/properties/cancel-reservation').set(auth(bob)).send({ reservation_id: id })).status, 404);
  assert.equal((await request(app).post('/api/properties/pay-reservation').set(auth(bob)).send({ reservation_id: id })).status, demo ? 404 : 503);
  assert.equal((await request(app).post('/api/properties/update-buyer-details').set(auth(alice)).send({ ...buyer, full_name: 'Updated Alice', reservation_id: id })).status, 200);
  assert.equal((await request(app).post('/api/properties/cancel-reservation').set(auth(alice)).send({ reservation_id: id })).status, 200);
  assert.equal((await request(app).post('/api/properties/cancel-reservation').set(auth(alice)).send({ reservation_id: id })).status, 409);
  const [units] = await db.execute('SELECT status FROM housing_units WHERE unit_id = ?', [unit]);
  assert.equal(units[0].status, 'Available');
});
test('Concurrent booking allows one winner only', async () => {
  const unit = await seedUnit('CONCURRENT');
  const results = await Promise.all([alice, bob, alice, bob].map(token => request(app).post('/api/properties/reserve').set(auth(token)).send({ ...buyer, unit_id: unit })));
  assert.equal(results.filter(r => r.status === 201).length, 1);
  assert.equal(results.filter(r => r.status === 409).length, 3);
  const [rows] = await db.execute("SELECT COUNT(*) AS count FROM unit_reservations WHERE unit_id = ? AND status = 'Pending'", [unit]);
  assert.equal(rows[0].count, 1);
});
test('Expired reservations cannot pay/edit/cancel and release before new booking', async () => {
  const unit = await seedUnit('EXPIRED');
  const booked = await request(app).post('/api/properties/reserve').set(auth(alice)).send({ ...buyer, unit_id: unit });
  const id = booked.body.data.reservation_id;
  await db.execute('UPDATE unit_reservations SET expires_at = DATE_SUB(NOW(), INTERVAL 1 MINUTE) WHERE reservation_id = ?', [id]);
  assert.equal((await request(app).post('/api/properties/pay-reservation').set(auth(alice)).send({ reservation_id: id })).status, demo ? 409 : 503);
  assert.equal((await request(app).post('/api/properties/update-buyer-details').set(auth(alice)).send({ ...buyer, reservation_id: id })).status, 409);
  const next = await request(app).post('/api/properties/reserve').set(auth(bob)).send({ ...buyer, unit_id: unit });
  assert.equal(next.status, 201);
  const [rows] = await db.execute('SELECT status FROM unit_reservations WHERE reservation_id = ?', [id]);
  assert.equal(rows[0].status, 'Expired');
  assert.equal((await request(app).post('/api/properties/cancel-reservation').set(auth(alice)).send({ reservation_id: id })).status, 409);
  const [units] = await db.execute('SELECT status FROM housing_units WHERE unit_id = ?', [unit]);
  assert.equal(units[0].status, 'Hold');
});
test('Expiration cleanup does not release a unit with an active confirmed sale', async () => {
  const unit = await seedUnit('LEGACY');
  await db.execute("UPDATE housing_units SET status = 'Sold' WHERE unit_id = ?", [unit]);
  await db.execute("INSERT INTO unit_reservations (unit_id, status, expires_at) VALUES (?, 'Pending', DATE_SUB(NOW(), INTERVAL 1 MINUTE)), (?, 'Confirmed', NULL)", [unit, unit]);
  await Promise.all([service.expireReservations(), service.expireReservations()]);
  const [units] = await db.execute('SELECT status FROM housing_units WHERE unit_id = ?', [unit]);
  assert.equal(units[0].status, 'Sold');
});
test('Payments disabled by default, or explicitly demo-only with no refund claims', async () => {
  assert.equal((await request(app).get('/api/config')).body.demo_payments, demo);
  const unit = await seedUnit('PAYMENT');
  const booked = await request(app).post('/api/properties/reserve').set(auth(alice)).send({ ...buyer, unit_id: unit });
  const id = booked.body.data.reservation_id;
  if (!demo) {
    assert.equal((await request(app).post('/api/properties/pay-reservation').set(auth(alice)).send({ reservation_id: id })).status, 503);
  } else {
    const results = await Promise.all([1, 2].map(() => request(app).post('/api/properties/pay-reservation').set(auth(alice)).send({ reservation_id: id })));
    assert.deepEqual(results.map(r => r.status).sort(), [200, 409]);
    assert.equal(results.find(r => r.status === 200).body.demo, true);
    assert.equal((await request(app).post('/api/properties/cancel-reservation').set(auth(alice)).send({ reservation_id: id })).status, 409);
    const [units] = await db.execute('SELECT status FROM housing_units WHERE unit_id = ?', [unit]);
    assert.equal(units[0].status, 'Sold');
  }
});
test('Invalid JSON is client error and response does not leak SQL', async () => {
  const response = await request(app).post('/api/auth/login').set('Content-Type', 'application/json').send('{broken');
  assert.equal(response.status, 400);
  assert.equal(response.body.message, 'Invalid JSON request.');
});
test('A database error rolls back the entire reservation mutation', async () => {
  const unit = await seedUnit('ROLLBACK');
  const booked = await request(app).post('/api/properties/reserve').set(auth(alice)).send({ ...buyer, unit_id: unit });
  const id = booked.body.data.reservation_id;
  await db.query(`CREATE TRIGGER test_reject_release BEFORE UPDATE ON housing_units FOR EACH ROW
    BEGIN IF NEW.unit_id = ${unit} AND NEW.status = 'Available' THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'fixture internal database error'; END IF; END`);
  try {
    const response = await request(app).post('/api/properties/cancel-reservation').set(auth(alice)).send({ reservation_id: id });
    assert.equal(response.status, 500);
    assert.equal(response.body.message, 'Server error. Please try again later.');
    const [reservations] = await db.execute('SELECT status FROM unit_reservations WHERE reservation_id = ?', [id]);
    const [units] = await db.execute('SELECT status FROM housing_units WHERE unit_id = ?', [unit]);
    assert.equal(reservations[0].status, 'Pending');
    assert.equal(units[0].status, 'Hold');
  } finally { await db.query('DROP TRIGGER IF EXISTS test_reject_release'); }
});

const test = require('node:test');
const assert = require('node:assert/strict');
const v = require('../lib/validation');
test('IDs must be bounded positive integers', () => {
  for (const invalid of [0, -1, '1 OR 1=1', '2.5', {}, null, true, '2147483648']) assert.throws(() => v.id(invalid));
  assert.equal(v.id('17'), 17);
});
test('Email validates and normalizes safely', () => {
  assert.equal(v.email('  User@Example.com '), 'user@example.com');
  for (const invalid of ['bad', '@example.com', [], { email: 'x@y.z' }]) assert.throws(() => v.email(invalid));
});
test('Passwords respect bcrypt UTF-8 byte limit', () => {
  assert.throws(() => v.password('short'));
  assert.throws(() => v.password('密'.repeat(25)));
  assert.equal(v.password('密'.repeat(24)), '密'.repeat(24));
});
test('Numbers reject non-numeric, missing, or non-finite inputs', () => {
  for (const invalid of ['', null, true, [], Infinity, 'NaN', '-1']) assert.throws(() => v.number(invalid, 'Price', 0.01, 100));
  assert.equal(v.number('12.34', 'Price', 0.01, 100), 12.34);
});
test('Particulars validate legacy separator and size constraints', () => {
  const body = { full_name: 'Alice', ic_number: 'P123', phone: '0123456789', remarks: 'Loan' };
  assert.equal(v.particulars(body), 'Name: Alice | IC: P123 | Phone: 0123456789 | Note: Loan');
  assert.throws(() => v.particulars({ ...body, full_name: 'Alice | IC: fake' }));
  assert.throws(() => v.particulars({ ...body, phone: {} }));
  assert.throws(() => v.particulars({ ...body, remarks: 'x'.repeat(2001) }));
});

-- Upgrade the schema supplied with the original project. Back up first.
-- Select your DB before running (mysql ... housing_sales_db < this-file).
-- This script is repeatable; it does not delete or guess ownership of old records.
SET @sql = IF(
  (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'buyers' AND COLUMN_NAME = 'role') = 0,
  "ALTER TABLE buyers ADD COLUMN role ENUM('buyer','admin') NOT NULL DEFAULT 'buyer'",
  'SELECT 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'unit_reservations' AND COLUMN_NAME = 'expires_at') = 0,
  'ALTER TABLE unit_reservations ADD COLUMN expires_at TIMESTAMP NULL',
  'SELECT 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'unit_reservations' AND INDEX_NAME = 'idx_reservations_buyer') = 0,
  'ALTER TABLE unit_reservations ADD INDEX idx_reservations_buyer (buyer_id, created_at)',
  'SELECT 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'unit_reservations' AND INDEX_NAME = 'idx_reservations_expiry') = 0,
  'ALTER TABLE unit_reservations ADD INDEX idx_reservations_expiry (status, expires_at)',
  'SELECT 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

UPDATE unit_reservations SET expires_at = DATE_ADD(created_at, INTERVAL 15 MINUTE)
WHERE status = 'Pending' AND expires_at IS NULL;

-- Review only. buyer_id NULL rows remain hidden, not automatically claimed.
SELECT reservation_id, unit_id, status FROM unit_reservations WHERE buyer_id IS NULL;
SELECT unit_id, COUNT(*) AS active_count FROM unit_reservations
WHERE status IN ('Pending', 'Confirmed') GROUP BY unit_id HAVING COUNT(*) > 1;

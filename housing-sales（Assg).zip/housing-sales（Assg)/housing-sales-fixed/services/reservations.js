const db = require('../database');
const { HttpError } = require('../lib/errors');
const HOLD_MINUTES = 15;
async function transaction(fn) {
  let connection;
  try {
    connection = await db.getConnection();
    await connection.beginTransaction();
    const result = await fn(connection);
    await connection.commit();
    return result;
  } catch (err) {
    if (connection) await connection.rollback().catch(() => {});
    throw err;
  } finally { if (connection) connection.release(); }
}
// Every mutation locks unit first, then reservation: consistent order prevents payment/expiry races.
async function lockUnit(connection, unitId) {
  const [units] = await connection.execute('SELECT * FROM housing_units WHERE unit_id = ? FOR UPDATE', [unitId]);
  if (!units.length) throw new HttpError(404, 'Property unit not found.');
  return units[0];
}
async function releaseExpiredForUnit(connection, unitId) {
  const [expired] = await connection.execute(
    `SELECT reservation_id FROM unit_reservations WHERE unit_id = ? AND status = 'Pending'
     AND COALESCE(expires_at, DATE_ADD(created_at, INTERVAL 15 MINUTE)) <= NOW() FOR UPDATE`, [unitId]);
  if (!expired.length) return;
  for (const row of expired) await connection.execute("UPDATE unit_reservations SET status = 'Expired' WHERE reservation_id = ? AND status = 'Pending'", [row.reservation_id]);
  const [active] = await connection.execute("SELECT reservation_id FROM unit_reservations WHERE unit_id = ? AND status IN ('Pending', 'Confirmed')", [unitId]);
  if (!active.length) await connection.execute("UPDATE housing_units SET status = 'Available' WHERE unit_id = ? AND status = 'Hold'", [unitId]);
}
async function expireReservations() {
  const [units] = await db.execute(`SELECT DISTINCT unit_id FROM unit_reservations WHERE status = 'Pending' AND COALESCE(expires_at, DATE_ADD(created_at, INTERVAL 15 MINUTE)) <= NOW() ORDER BY unit_id`);
  for (const unit of units) await transaction(async connection => { await lockUnit(connection, unit.unit_id); await releaseExpiredForUnit(connection, unit.unit_id); });
}
async function reserve(buyerId, unitId, remarks) {
  return transaction(async connection => {
    const unit = await lockUnit(connection, unitId);
    await releaseExpiredForUnit(connection, unitId);
    const [current] = await connection.execute('SELECT status FROM housing_units WHERE unit_id = ?', [unitId]);
    const [active] = await connection.execute("SELECT reservation_id FROM unit_reservations WHERE unit_id = ? AND status IN ('Pending', 'Confirmed')", [unitId]);
    if (current[0].status !== 'Available' || active.length) throw new HttpError(409, 'This property is no longer available.');
    const [result] = await connection.execute(
      `INSERT INTO unit_reservations (buyer_id, unit_id, booking_fee_myr, status, remarks, expires_at)
       VALUES (?, ?, 1000.00, 'Pending', ?, DATE_ADD(NOW(), INTERVAL 15 MINUTE))`, [buyerId, unit.unit_id, remarks]);
    await connection.execute("UPDATE housing_units SET status = 'Hold' WHERE unit_id = ?", [unitId]);
    return { reservation_id: result.insertId, unit_id: unitId, hold_minutes: HOLD_MINUTES };
  });
}
async function mutateOwnReservation(buyerId, reservationId, action, remarks) {
  const [refs] = await db.execute('SELECT unit_id FROM unit_reservations WHERE reservation_id = ? AND buyer_id = ?', [reservationId, buyerId]);
  if (!refs.length) throw new HttpError(404, 'Reservation not found.');
  return transaction(async connection => {
    const unit = await lockUnit(connection, refs[0].unit_id);
    const [rows] = await connection.execute(`SELECT *, COALESCE(expires_at, DATE_ADD(created_at, INTERVAL 15 MINUTE)) <= NOW() AS is_expired FROM unit_reservations WHERE reservation_id = ? AND buyer_id = ? FOR UPDATE`, [reservationId, buyerId]);
    const reservation = rows[0];
    if (!reservation) throw new HttpError(404, 'Reservation not found.');
    if (reservation.status !== 'Pending' || reservation.is_expired) throw new HttpError(409, 'Only active pending reservations may be changed. Confirmed sales require administrator review; no refund is processed here.');
    if (unit.status !== 'Hold') throw new HttpError(409, 'Property and reservation statuses do not match. Contact the administrator.');
    if (action === 'edit') {
      await connection.execute('UPDATE unit_reservations SET remarks = ? WHERE reservation_id = ?', [remarks, reservationId]);
    } else if (action === 'pay') {
      await connection.execute("UPDATE unit_reservations SET status = 'Confirmed' WHERE reservation_id = ?", [reservationId]);
      await connection.execute("UPDATE housing_units SET status = 'Sold' WHERE unit_id = ?", [unit.unit_id]);
    } else if (action === 'cancel') {
      await connection.execute("UPDATE unit_reservations SET status = 'Cancelled' WHERE reservation_id = ?", [reservationId]);
      const [active] = await connection.execute("SELECT reservation_id FROM unit_reservations WHERE unit_id = ? AND status IN ('Pending', 'Confirmed')", [unit.unit_id]);
      if (!active.length) await connection.execute("UPDATE housing_units SET status = 'Available' WHERE unit_id = ? AND status = 'Hold'", [unit.unit_id]);
    } else throw new Error('Unsupported reservation action.');
  });
}
async function listOwnReservations(req, res) {
  await expireReservations();
  const [rows] = await db.execute(`SELECT r.reservation_id, r.buyer_id, r.unit_id, r.booking_fee_myr, r.status, r.remarks, r.created_at,
    COALESCE(r.expires_at, DATE_ADD(r.created_at, INTERVAL 15 MINUTE)) AS expires_at, h.project_name, h.unit_number
    FROM unit_reservations r JOIN housing_units h ON r.unit_id = h.unit_id
    WHERE r.buyer_id = ? ORDER BY r.created_at DESC, r.reservation_id DESC`, [req.user.id]);
  res.json({ status: 'success', count: rows.length, data: rows });
}
module.exports = { transaction, reserve, mutateOwnReservation, expireReservations, listOwnReservations };
